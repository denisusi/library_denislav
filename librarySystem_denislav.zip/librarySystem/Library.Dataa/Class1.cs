﻿using System;

namespace Library.Dataa
{
    public class Class1
    {
    }
}

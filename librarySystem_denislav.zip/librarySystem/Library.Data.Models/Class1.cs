﻿using System;

namespace Library.Data.Models
{
    public class Class1
    {
    }
}

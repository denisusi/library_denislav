﻿using System;

namespace Library.View.Models
{
    public class Class1
    {
    }
}

﻿using System;

namespace Library.Services
{
    public class Class1
    {
    }
}

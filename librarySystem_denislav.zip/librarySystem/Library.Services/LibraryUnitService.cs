﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Library.Services
{
    class LibraryUnitService
    {
        public int Create_LibraryUnit(string condition);
    }
}
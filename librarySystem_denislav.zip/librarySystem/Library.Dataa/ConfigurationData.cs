﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Library.Dataa
{
    class ConfigurationData
    {
        public const string ConnString = "Server=DENZ0\\SQLEXPRESS;Database=LibraryDenis;Integrated Security=true;";
    }
}